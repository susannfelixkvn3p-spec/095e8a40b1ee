// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("wasm emscripten\n", stdout);
  return lionss_run_workload("wasm-emscripten");
}
