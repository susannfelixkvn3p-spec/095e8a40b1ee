// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("broken links"); }
int main(){
  announce();
  return lionss_run_workload("broken-links");
}
