// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("decoder fuzz"); }
int main(){
  announce();
  return lionss_run_workload("decoder-fuzz");
}
