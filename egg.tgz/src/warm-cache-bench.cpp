// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("warm cache bench\n", stdout);
  return lionss_run_workload("warm-cache-bench");
}
