// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("edge case tests\n", stdout);
  return lionss_run_workload("edge-case-tests");
}
